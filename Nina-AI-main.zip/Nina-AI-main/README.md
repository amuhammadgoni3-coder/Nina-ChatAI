# Nina-AI
Voice note AI
